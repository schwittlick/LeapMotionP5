package example;

import com.leapmotion.leap.Finger;
import com.leapmotion.leap.FingerList;
import com.leapmotion.leap.Frame;
import com.leapmotion.leap.Hand;
import com.leapmotion.leap.Screen;
import com.leapmotion.leap.Vector;
import com.onformative.leap.LeapMotionP5;

import processing.core.PApplet;

public class CalibrationTest extends PApplet {
  LeapMotionP5 leap;
  float[] pixelPoint = new float[2];
  public void setup(){
    size(600, 600);
    
    leap = new LeapMotionP5(this);
    pixelPoint[0] = 0;
    pixelPoint[1] = 0;
  }
  
  public void draw(){
    println("Frame");
    Frame frame = leap.getFrame();
    println("Frame id: " + frame.id()
      + ", timestamp: " + frame.timestamp()
      + ", hands: " + frame.hands().count()
      + ", fingers: " + frame.fingers().count()
      + ", tools: " + frame.tools().count());
    
    // Get the first hand
    Hand hand = frame.hands().get(0);
    // Get fingers
    FingerList fingers = hand.fingers();
      
    if (!frame.hands().empty()) {
    
    //Check if the hand has fingers.
    if (!fingers.empty()) {
      
      //Calculate the hand's average finger tip position
      Vector avgPos = Vector.zero();
      for (Finger finger : fingers) {
        avgPos = avgPos.plus(finger.tipPosition());
      }
      avgPos = avgPos.divide(fingers.count());
      println("Hand has " + fingers.count() + " fingers, average finger tip position: " + avgPos);
      
      //Tell the position of the leaper's (user's) fingertip.
      Screen screen = leap.getController().calibratedScreens().get(0);
      Vector bottomLeftCorner = screen.bottomLeftCorner();
      Finger pointer = fingers.get(0);
      Vector point = pointer.tipPosition();
      println("You are pointing at: " + point);
      float distance = screen.distanceToPoint(point);
      println("The distance from the screen to your finger tip is: " + distance + "mm");
      
      //Tell what point on the screen the leaper is pointing at.
      Vector screenPoint = screen.intersect(pointer, true);
      println("You are pointing at this point on the screen: " + screenPoint);
      //The vector of the bottom left corner
      println("Bottom-left Corner: " +  bottomLeftCorner);
      
      //Tell what pixel coordinate the leaper is pointing to.
      float pixelX = width*screenPoint.get(0);
      //Without subtracting from 1, the Y is inverted.
      float pixelY = height*(1-abs(screenPoint.get(1)));
      println("X Pixel: " + pixelX + "Y Pixel: " + pixelY);
      
      //Give the pixel values to pixelPoint for the draw() function.
      pixelPoint[0] = pixelX;
      pixelPoint[1] = pixelY;
      
    }
  }
  
  //Get the hand's normal vector and direction
  Vector normal = hand.palmNormal();
  Vector direction = hand.direction();
  
  //Calculate the hand's pitch, roll, and yaw angles
  println("Hand pitch: " + Math.toDegrees(direction.pitch()) + " degrees, "
    + "roll: " + Math.toDegrees(normal.roll()) + " degrees, "
    + "yaw: " + Math.toDegrees(direction.yaw()) + " degrees\n");
    

  
  }
}
