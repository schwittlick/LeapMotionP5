package example;

import processing.core.PApplet;
import processing.core.PVector;

import com.onformative.leap.LeapMotionP5;

public class FingerIn3D extends PApplet {
  LeapMotionP5 leap;

  public void setup() {
    size(500, 500, P3D);
    leap = new LeapMotionP5(this);
  }

  public void draw() {
    background(0);
    strokeWeight(10);
    stroke(255);
    PVector loc = leap.getFingerPVector(0);
    point(loc.x, loc.y, 0);
  }
}
