package example;

import com.leapmotion.leap.Finger;
import com.leapmotion.leap.Frame;
import com.leapmotion.leap.Hand;
import com.onformative.leap.LeapMotionP5;

import processing.core.PApplet;
import processing.core.PVector;

public class HandReconstruction extends PApplet {
  LeapMotionP5 leap;

  public void setup() {
    size(900, 900, P3D);
    leap = new LeapMotionP5(this);
    stroke(255);
    fill(90);
  }

  public void draw() {
    background(0);
    lights();


    for (Hand hand : leap.getHandList()) {
      pushMatrix();
      PVector handPosition = leap.convertHandToPVector(hand);
      translate(handPosition.x, handPosition.y, handPosition.z);
      box(10);
      popMatrix();
    }

    for (Finger finger : leap.getFingerList()) {
      pushMatrix();
      PVector fingerPosition = leap.convertFingerToPVector(finger);
      translate(fingerPosition.x, fingerPosition.y, fingerPosition.z);
      sphere(5);
      popMatrix();
    }

    for (Hand hand : leap.getHandList()) {
      PVector handPosition = leap.convertHandToPVector(hand);
      for (Finger finger : leap.getFingerList(hand)) {
        PVector fingerPosition = leap.convertFingerToPVector(finger);
        line(handPosition.x, handPosition.y, handPosition.z, fingerPosition.x, fingerPosition.y,
            fingerPosition.z);

        float fingerLength = finger.length();
        System.out.println("fingerlength: " + fingerLength);
        float distance =
            dist(handPosition.x, handPosition.y, handPosition.z, fingerPosition.x,
                fingerPosition.y, fingerPosition.z);
        float percentage = fingerLength / distance;
        PVector anklePosition = new PVector();
        anklePosition.x = lerp(handPosition.x, fingerPosition.x, percentage);
        anklePosition.y = lerp(handPosition.y, fingerPosition.y, percentage);
        anklePosition.z = lerp(handPosition.z, fingerPosition.z, percentage);
        pushMatrix();
        translate(anklePosition.x, anklePosition.y, anklePosition.z);
        sphere(5);
        popMatrix();
        System.out.println("distance hand to tip: " + distance);
      }
    }
  }
}
