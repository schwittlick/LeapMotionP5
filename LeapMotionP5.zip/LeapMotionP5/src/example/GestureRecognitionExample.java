package example;

import com.onformative.leap.LeapMotionP5;

import processing.core.PApplet;

public class GestureRecognitionExample extends PApplet {
  LeapMotionP5 leap;
  String lastGesture = "";

  @SuppressWarnings("static-access")
  public void setup() {
    size(500, 500);
    textSize(30);

    leap = new LeapMotionP5(this);
    
    leap.addGesture(leap.gestures.SWIPE_LEFT);
    leap.addGesture(leap.gestures.SWIPE_RIGHT);
    leap.addGesture(leap.gestures.CIRCLE);
    leap.addGesture(leap.gestures.TRIANGLE);
    leap.addGesture(leap.gestures.RECTANGLE);
    leap.addGesture(leap.gestures.ZIG_ZAG);


    leap.start();
  }

  public void draw() {
    background(0);
    leap.gestures.one.draw();
    leap.update();
    text(lastGesture, 30, 30);
  }

  public void gestureRecognized(String gesture) {
    lastGesture = gesture;
  }
}
