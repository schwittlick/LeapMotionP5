package com.onformative.leap.gestures.transitions;

import java.util.LinkedList;

import com.leapmotion.leap.Frame;
import com.onformative.leap.LeapMotionP5;
import com.onformative.leap.gestures.Gesture;

public class OneToTwoFingerTransitionGesture extends Gesture {
  private int from = 1;
  private int to = 2;

  public OneToTwoFingerTransitionGesture(LeapMotionP5 leap) {
    super(leap);
    // TODO Auto-generated constructor stub
  }

  public boolean check() {
    boolean returnValue = false;


    LinkedList<Frame> last10Frames = leap.getFrames(10);

    for (Frame frame : last10Frames) {
      int fingerCountFirstRound = leap.getFingerCount(frame);
      if (fingerCountFirstRound == from) {
        long frameNumberWithRightFingercount = frame.id();

        for (Frame frame2 : last10Frames) {
          if (frame2.id() > frameNumberWithRightFingercount) {
            int fingerCountSecondRound = leap.getFingerCount(frame2);
            if (fingerCountSecondRound == to) {
              returnValue = true;
            }
          }
        }
      }

    }
    return returnValue;
  }

  /**
   * 
   * @return
   */
  public String getShortname() {
    return "onetotwo";
  }
}
