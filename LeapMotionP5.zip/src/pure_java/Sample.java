package pure_java;

import java.io.IOException;

import com.leapmotion.leap.Controller;
import com.leapmotion.leap.Finger;
import com.leapmotion.leap.FingerList;
import com.leapmotion.leap.Frame;
import com.leapmotion.leap.Hand;
import com.leapmotion.leap.Listener;
import com.leapmotion.leap.Vector;

class SampleListener extends Listener {
  public void onInit(Controller controller) {
    System.out.println("Initialized");
  }

  public void onConnect(Controller controller) {
    System.out.println("Connected");
  }

  public void onDisconnect(Controller controller) {
    System.out.println("Disconnected");
  }

  public void onExit(Controller controller) {
    System.out.println("Exited");
  }

  public void onFrame(Controller controller) {
    // Get the most recent frame and report some basic information
    Frame frame = controller.frame();
    //System.out.println("Frame id: " + frame.id() + ", timestamp: " + frame.timestamp()
    //    + ", hands: " + frame.hands().count() + ", fingers: " + frame.fingers().count()
    //    + ", tools: " + frame.tools().count());

    if (!frame.hands().empty()) {
      // Get the first hand
      Hand hand = frame.hands().get(0);

      // Check if the hand has any fingers
      FingerList fingers = hand.fingers();
      if (!fingers.empty()) {
        // Calculate the hand's average finger tip position
        Vector avgPos = Vector.zero();
        for (Finger finger : fingers) {
          avgPos = avgPos.plus(finger.tipPosition());
          System.out.println("  "+finger.tipVelocity().getY());
        }
        avgPos = avgPos.divide(fingers.count());
        System.out.println("Hand has " + fingers.count()
            + " fingers, average finger tip position: " + avgPos);
      }

      // Get the hand's sphere radius and palm position
      System.out.println("Hand sphere radius: " + hand.sphereRadius() + " mm, palm position: "
          + hand.palmPosition());

      // Get the hand's normal vector and direction
      Vector normal = hand.palmNormal();
      Vector direction = hand.direction();
      System.out.println();

       //Calculate the hand's pitch, roll, and yaw angles
      System.out.println("Hand pitch: " + Math.toDegrees(direction.pitch()) + " degrees, "
          + "roll: " + Math.toDegrees(normal.roll()) + " degrees, " + "yaw: "
          + Math.toDegrees(direction.yaw()) + " degrees\n");
    }
  }
}


public class Sample {
  public static void main(String[] args) {
    // Create a sample listener and controller
    SampleListener listener = new SampleListener();
    Controller controller = new Controller();

    // Have the sample listener receive events from the controller
    controller.addListener(listener);

    // Keep this process running until Enter is pressed
    System.out.println("Press Enter to quit...");
    try {
      System.in.read();
    } catch (IOException e) {
      e.printStackTrace();
    }

    // Remove the sample listener when done
    controller.removeListener(listener);
  }
}
