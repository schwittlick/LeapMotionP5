package com.onformative.leap.gestures;

import com.onformative.leap.LeapMotionP5;


public class ClickGesture extends Gesture {

  public ClickGesture(LeapMotionP5 leap) {
    super(leap);
    // TODO Auto-generated constructor stub
  }

  public boolean check() {
    return false;
  }
}
