package example;

import com.leapmotion.leap.Frame;
import com.onformative.leap.LeapMotionP5;

import processing.core.PApplet;

public class LowLevelAccessFrame extends PApplet {
  LeapMotionP5 leap;

  public void setup() {
    size(500, 500);
    leap = new LeapMotionP5(this);
  }

  public void draw() {
    Frame frame = leap.getCurrentFrame();
    // do some processing of the frame
    // this is the same frame you'd get if you would use the callback
  }
}
