package example;

import com.leapmotion.leap.Hand;
import com.onformative.leap.LeapMotionP5;

import processing.core.PApplet;

public class FingerExample extends PApplet {
  LeapMotionP5 leap;

  public void setup() {
    size(500, 500);
    leap = new LeapMotionP5(this);
  }

  public void draw() {
    background(0);
    ellipse(leap.leapToScreenX(leap.getFinger(0).tipPosition().getX()),
        leap.leapToScreenY(leap.getFinger(0).tipPosition().getY()), 20, 20);
  //ellipse(leap.leapToScreenX(leap.getPointable(0).tipPosition().getX()),
   //     leap.leapToScreenY(leap.getPointable(0).tipPosition().getY()), 20, 20);
  
  /*Hand hand = leap.getHand(0);
  hand.*/
    
    System.out.println(leap.getClass().getName());
  }
}
