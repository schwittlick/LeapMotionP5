package example;

import com.onformative.leap.LeapMotionP5;
import com.onformative.leap.gestures.OneDollarGestures;

import processing.core.PApplet;

public class OneDollarLeapExample extends PApplet {
  LeapMotionP5 leap;

  OneDollarGestures one;
  String lastGesture = "";

  public void setup() {
    size(500, 500);
    frameRate(500);
    textSize(30);

    leap = new LeapMotionP5(this);
    one = new OneDollarGestures(this, leap);

    one.addGesture("circle");
    one.addGesture("triangle");
    one.addGesture("rectangle");
    one.addGesture("x");
    // one.addGesture("check");
    // one.addGesture("caret");
    one.addGesture("zig-zag");
    one.addGesture("arrow");
    // one.addGesture("leftsquarebracket");
    // one.addGesture("rightsquarebracket");
    one.addGesture("v");
    // one.addGesture("delete");
    // one.addGesture("leftcurlybrace");
    // one.addGesture("rightcurlybrace");
    one.addGesture("star");
    one.addGesture("pigtail");

    one.start();
  }

  public void detected(String gesture, int x, int y, int c_x, int c_y) {
    lastGesture = gesture;
  }

  public void draw() {
    //System.out.println(frameRate);
    background(0);
    one.draw();
    one.update();

    text(lastGesture, 40, 40);
  }
  
  public void exit(){
    one.exit();
  }
}
