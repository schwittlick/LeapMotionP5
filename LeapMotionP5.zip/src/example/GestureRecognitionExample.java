package example;

import com.onformative.leap.LeapMotionP5;

import processing.core.PApplet;

public class GestureRecognitionExample extends PApplet {
  LeapMotionP5 leap;
  String lastGesture = "";

  public void setup() {
    size(500, 500);
    textSize(30);

    leap = new LeapMotionP5(this);
    //leap.addGesture("swipeleft");
    //leap.addGesture("swiperight");
    leap.addGesture("circle");
    leap.addGesture("delete");
    //leap.addGesture("victory");
    leap.start();
  }

  public void draw() {
    background(0);
    //leap.gestures.one.draw();
    leap.update();
    text(lastGesture, 30, 30);
  }

  public void gestureRecognized(String gesture) {
    lastGesture = gesture;
  }
}
