package example;

import processing.core.PApplet;
import processing.core.PVector;

import com.onformative.leap.LeapMotionP5;

public class RotationTest extends PApplet {
  LeapMotionP5 leap;

  public void setup() {
    size(500, 500, P3D);
    leap = new LeapMotionP5(this);
  }

  public void draw() {
    leap.getRotationsMatrix(leap.getHand(0));
  }
}
