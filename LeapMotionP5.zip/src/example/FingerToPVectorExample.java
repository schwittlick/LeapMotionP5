package example;

import com.onformative.leap.LeapMotionP5;

import processing.core.PApplet;
import processing.core.PVector;

public class FingerToPVectorExample extends PApplet {
  LeapMotionP5 leap;

  public void setup() {
    size(500, 500);
    leap = new LeapMotionP5(this);
  }

  public void draw() {
    background(0);
    PVector fingerPos = leap.convertFingerToPVector(leap.getFinger(0));
    ellipse(fingerPos.x, fingerPos.y, 20, 20);
  }
}
