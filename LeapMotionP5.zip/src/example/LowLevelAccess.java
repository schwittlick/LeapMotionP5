package example;

import com.leapmotion.leap.Frame;
import com.onformative.leap.LeapMotionP5;

import processing.core.PApplet;

public class LowLevelAccess extends PApplet {
  LeapMotionP5 leap;

  public void setup() {
    size(500, 500);
    leap = new LeapMotionP5(this);
  }

  public void draw() {
    for (Frame frame : leap.getFrames()) {
      // do something with the last 250 frames
    }
  }
}
