package scope;

import processing.core.PApplet;

public class LeftToRightWave extends Wave {

  public LeftToRightWave(PApplet p, int color) {
    super(p, color);
    wavePosition = p.width + 10;
  }

  public void draw() {
    if (wavePosition < p.width + 10) {
      wavePosition += 4;
    }
    p.pushStyle();
    p.stroke(color);
    p.strokeWeight(10);
    p.line(wavePosition, 0, wavePosition, p.height);
    p.popStyle();
  }

  public void start() {
    this.wavePosition = 0;
  }

}
