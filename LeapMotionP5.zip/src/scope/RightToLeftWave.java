package scope;

import processing.core.PApplet;

public class RightToLeftWave extends Wave{

  public RightToLeftWave(PApplet p, int color) {
    super(p, color);
    wavePosition = -10;
  }

  public void draw() {
    if (wavePosition > -10) {
      wavePosition -= 4;
    }
    p.pushStyle();
    p.stroke(color);
    p.strokeWeight(10);
    p.line(wavePosition, 0, wavePosition, p.height);
    p.popStyle();
  }

  public void start() {
    this.wavePosition = p.width;
  }
}
