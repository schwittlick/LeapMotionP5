package scope;

import processing.core.PApplet;

public class BottomToTopWave extends Wave {

  public BottomToTopWave(PApplet p, int color) {
    super(p, color);
    this.wavePosition = -10;
  }

  public void draw() {
    if (wavePosition > - 10) {
      wavePosition -= 4;
    }
    p.pushStyle();
    p.stroke(color);
    p.strokeWeight(10);
    p.line(0, wavePosition, p.width, wavePosition);
    p.popStyle();
  }

  public void start() {
    this.wavePosition = p.height;
  }

}
